#characterClass.py
#bitches love characters!
import battleModule
import math
from playerBackpack import *
import random

EXPRequired = [1, 50, 100, 200, 300, 500, 1000, 1500, 2000, 5000, 7500, 10000, 12500,
        15555]

class Character():
    def __init__(self, name, level):
        self.__dead = False #HP went WWAAAYYY beyond 0 and is now out for good
        self.__hero = False #distinguishes false for enemy, true for friendly
        self.__incap = False #incapacitated or not, probs HP <= 0, or paralyzed, or scared, etc
        self.__name = "DerpFace BucketHead"
        self.__level = 1
        self.__EXP = 1

        self.setName(name)
        self.setLevel(level)#set starting level
        self.setEXP(calculateEXP(level))#set EXP starting point based on starting level

        #randomized base stats 
        self.__baseAttack = random.randint(45, 60)
        self.__baseBattleSpeed = random.randint(45, 60)
        self.__baseDefense = random.randint(45, 60)
        self.__baseMagic = random.randint(45, 60)
        
        self.__HPRegenRate = random.randint(10, 20) / 10.0
        self.__MPRegenRate = random.randint(10, 20) / 10.0
        self.__walkingSpeed = random.randint(1, 3) + 2

        #stats to be derived from base stats
        self.__attack = 0
        self.__accuracy = 93
        self.__battleSpeed = 0
        self.__defense = 0
        self.__evasion = 2
        self.__maxHP = 0
        self.__magic = 0
        self.__maxMP = 0
        
        #render stats derived from base stats
        self.renderStats()#RENDER STATS!!!!!
        self.__HP = self.__maxHP
        self.__MP = self.__maxMP
        
        #other things
        self.__primaryItemEquipped  = "no primary item"
        self.__secondaryItemEquipped = "no secondary item"
        self.__headgear = "no headgear"
        self.__footgear = "no footgear"
        self.__body = "no body"
        self.__rings = []
        self.__backpack = Backpack()
        self.__statusEffects = []

        
    def attack(self, dfdr):#friends and foes TODO
        #choose what kind of attack, normal, magic, item, etc
        #determineAttack
        attackChoice = self.determineAttack(dfdr)
        if(attackChoice < 500):#TODO list different attacks and %
            return self.basicAttack(dfdr)

    def basicAttack(self, dfdr): #effect)
        print("*" if self.getHero() else " ", end='')
        print(self.__name, "attacks", dfdr.getName(), end='') #dialogue
        
        #resolve miss
        if(random.randint(0, 101) <= self.__accuracy - dfdr.getEvasion()): #attack hits!
            #resolve crit
            critPower = 1
            if(random.randint(0, 101) <= 3): # attack deals critical damage
                critPower = 1.5 # damage will be increased X1.5
               
            mod = (100 - random.randint(0, 15)) / 100 #damage modifier between 85%-100%
            dmg = 1 + int((((self.__attack / dfdr.getDefense()) * 2) * critPower) * mod)#damage equation
            print(" and deals", dmg, "damage!") # show damage
            return dmg                    
        else:    #attack missed
            print("... but misses completely.")#dialogue
            return 0 #the attack missed and deals no damage

    def damageHP(self, damageAmount):
        self.__HP -= int(damageAmount) #update defender's current HP
        #if(damageAmount > self.__HP * .75):#if damage dealt was greater than 75% of HP
            #self.__incap = True #the world is not yet ready for incap
        if (self.__HP <= 0):
            self.__HP = 0
            #self.__incap = True

    def determineAttack(self, dfdr):
        #TODO determines best move based on paramteters (unfinished)
        #friends foes, their HP and statsus ailments
        return random.randint(0, 99)

    def useMP(self, amount):
        self.__mp -= int(amount)
        if (self.__MP <= 0):
            self.__MP = 0

    def fallInBattle(self):
        print("!!!!"+self.__name, "is defeated!!!!!")

    def gainEXP(self, amount):
        print(self.__name, "earns", amount, "EXP!")
        self.__EXP += int(amount)
        while(checkLevel(self.__level, self.__EXP)):
            self.levelUp()
            print(self.__name, "reached Level", str(self.__level) + "!")

    #fetchers
    def getAttack(self):
        return int(self.__attack)
    def getAccuracy(self):
        return int(self.__accuracy)
    def getBattleSpeed(self):
        return int(self.__battleSpeed)
    def getDefense(self):
        return int(self.__defense)
    def getEvasion(self):
        return int(self.__evasion)
    def getFriendly(self):
        return bool(self.__hero)
    def getWalkingSpeed(self):
        return int(self.__walkingSpeed)
    def getHP(self):
        return int(self.__HP)
    def getHero(self):
        return bool(self.__hero)
    def getIncap(self):
        return int(self.__incap)
    def getMaxHP(self):
        return int(self.__maxHP)
    def getLevel(self):
        return int(self.__level)
    def getMP(self):
        return int(self.__MP)
    def getMaxMP(self):
        return int(self.__maxMP)
    def getMagic(self):
        return int(self.__magic)
    def getName(self):
        return str(self.__name)

    def healHP(self, healAmount):
        #determine heal amount
        if(healAmount in ["full", "max", "all"]):
            self.__HP = self.__maxHP
        else:
            self.__HP += int(healAmount) #add health to hp
            if (self.__HP > self.__maxHP): # hp can only go up to MAX HP
                self.__HP = self.__maxHP #if more, hp = maxhp            
                
    def healMP(self, healAmount):
        #determine heal amount
        if(healAmount in ["full", "max", "all"]):
            self.__MP = self.__maxMP
        else:
            self.__MP += int(healAmount) #add health to hp
            if(self.__MP > self.__maxMP): # hp can only go up to MAX HP
                self.__MP = self.__maxMP #if more, hp = maxhp

    def isAlive(self):
        True if self.__HP > 1 else False

    def levelUp(self):
        self.__level += 1
        self.renderStats()

    def passiveRegen(self, modifier):
        if(self.__HP > 0 and not self.__incap):#only regen if not KO            
            self.healHP(modifier * self.__HPRegenRate)
            self.healMP(modifier * self.__HPRegenRate)

    def renderStats(self):
        self.__attack = int(((self.__baseAttack * 2 * self.__level) / 100.0) + (self.__level + 5))
        self.__battleSpeed = int(((self.__baseBattleSpeed * 2) * self.__level) / 100 + self.__level + 5)
        self.__defense = int(((self.__baseDefense * 2) * self.__level) / 100.0 + self.__level + 5)
        self.__evasion += int(self.__battleSpeed / 13)
        self.__maxHP = int(random.randint(5, 15) + (random.randint(0, self.__baseAttack - 45) + 1) +
            random.randint(0, (self.__baseDefense - 45) + self.__level * 2))
        self.__magic = int(((self.__baseMagic * 2) * self.__level) / 100 + self.__level + 5)
        self.__maxMP = int(random.randint(self.__baseMagic, self.__baseMagic + 45))

    def revive(self):
        self.healHP("full")
        self.healMP("full")
        self.__incap = False
        
       #mutators 
    def setName(self, newName):
        self.__name = str(newName)
    def setAttack(self, amount):
        self.__baseAttack = int(amount)
    def setBattleSpeed(self, amount):
        self.__battleSpeed = amount
    def setDefense(self, amount):
        self.__defense = amount
    def setEXP(self, amount):
        self.__EXP = int(amount)
    def setHero(self, friendOrFoe):
        if(type(friendOrFoe) == bool):
            self.__hero = friendOrFoe
        else:
            print("ERROR:  FRIENDORFOE not boolean value!!!")
            print("TERMINATING....")
            exit(1)
    def setLevel(self, level):
        self.__level = 1 if level < 1 else int(level)
        #TODO MATCH EXP AMOUNT TO LEVEL
        #self.__EXP = 
    def setMaxHP(self, amount):
        self.__MaxHP = int(amount)
    def setMaxMP(self, amount):
        self.__MaxMP = int(amount)
    def setWalkingSpeed(self, amount):
        self.__walkingSpeed = int(amount)

    def showHP(self):
        print(self.__name, "HP:", self.__HP, "/", self.__maxHP, end=" ")
    
    def showStats(self):
        print( str(self.__name), int(self.__maxHP),\
               int(self.__attack), int(self.__defense) )

def calculateEXP(level):
    return EXPRequired[level]

def checkLevel(charLevel, charEXP):
    if(charEXP >= EXPRequired[charLevel + 1]):
        return True
    return False
    

    
