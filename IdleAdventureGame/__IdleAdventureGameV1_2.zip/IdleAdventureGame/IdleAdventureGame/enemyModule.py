#enemyModule
import characterClass
import math
import random
import partyModule
    

class Enemy(characterClass.Character):
    def __init__(self):
        characterClass.Character.__init__(self, "derp", 1) 
        self.__baseEXPYield = 1
        self.__baseCommonYield = 1
        self.__baseScarceYield = 1
        self.__baseRareYield = 1

    def getBaseEXPYield(self):
        return self.__baseEXPYield


    def yieldEXP(self): #returns an int
        return math.sqrt(self.__baseEXPYield * self.getLevel())
    def yieldCommon(self):#returns rate at which drop occurs
        return math.sqrt(self.__baseCommonYield * self.__level)
    def yieldScarce(self):
        return math.sqrt(self.__baseScarceYield * self.__level)
    def yieldRare(self):
        return math.sqrt(self.__baseScareYield * self.__level)
    
class Mettuar(Enemy):
    def __init__(self, level):
        characterClass.Character.__init__(self, "Mettuar", random.randint(level-5, level-1))
        Enemy.__init__(self)
        self.__baseEXPYield = 9
        self.__baseCommonYield = 5
        self.__baseScarceYield = 1
        self.__baseRareYield = 0

class SniperJoe(Enemy):
    def __init__(self, level):
        characterClass.Character.__init__(self, "SniperJoe", random.randint(level-3, level))
        Enemy.__init__(self)
        self.__baseEXPYield = 12
        self.__baseCommonYield = 6
        self.__baseScarceYield = 3
        self.__baseRareYield = 1      

class KernalKiller(Enemy):
    def __init__(self, level):
        characterClass.Character.__init__(self, "Kernal Killer", random.randint(level-1, level+1))
        Enemy.__init__(self)
        self.__baseEXPYield = 15
        self.__baseCommonYield = 8
        self.__baseScarceYield = 5
        self.__baseRareYield = 2 

class FaceKicker(Enemy):
    def __init__(self, level):
        characterClass.Character.__init__(self, "FaceKicker", random.randint(level, level+3))
        Enemy.__init__(self)
        self.__baseEXPYield = 21
        self.__baseCommonYield = 13
        self.__baseScarceYield = 8
        self.__baseRareYield = 2

def assignEnemyNo(enemy, party):
    similarEnemyCount = 1# does not count self #starts at one so second enemy generated will be Dude2 and so forth
    for member in party:
        if(enemy.getName()[0 : 5] == member.getName()[0 : 5]):#if first 5 letters of each string identical
            similarEnemyCount += 1
            enemy.setName(enemy.getName() + " " + str(similarEnemyCount))

def averageEnemyLevel(enemyTeam):
    levelTotal = 0
    for member in enemyTeam:
        levelTotal += member.getLevel()
    return int(levelTotal / len(enemyTeam))

def encounterCheck(partyLevel):
    baseEncounterRate = 25
    if(random.randint(0, 100) < baseEncounterRate + partyLevel):
        print("Some enemies are approaching!")
        return True
    else:
        return False

def isAlive(enemyTeam):
    for member in enemyTeam:
        if(member.getHP() > 0 and not member.getIncap()):
            return True
    return False

def randomEnemyTeam(teamSize, level):
    #print("building enemy team...")
    party = []
    memberCount = 1
    enemyLevel = 5#TODO for now!
    while(memberCount <= teamSize):
        enemy = randomEnemy(enemyLevel)# get a randomly generated baddie
        assignEnemyNo(enemy, party)# Mettuar 2, SniperJoe 4
        party.append(enemy)#add to list of enemies
        memberCount += 1#increment counter
    return party#return fully made party of baddies

def randomEnemy(level):
    #print("building single enemy at a time")
    choice = random.randint(0, 10)
    if(choice == 0):
        return FaceKicker(level)
    elif(choice < 5):
        return Mettuar(level)
    elif(choice < 7):
        return KernalKiller(level)
    else:
        return SniperJoe(level)

def rewardEXP(enemyTeam):
    totalEXP = 0
    for enemy in enemyTeam:
       totalEXP += enemy.yieldEXP() #EXP reward
    print("rewardEXP() totalEXP:", totalEXP)#Print test
    return int(totalEXP)

def rewardItem(enemyTeam):
    #TODO reward items
    for enemy in enemyTeam:
        #item rewards
        if(random.randint(0, 100) < enemy.yieldCommon()):
           pass #return commonLootList[random.randint(0, 100)]
        elif(random.randint(0, 100) < enemy.yieldScarce()):
            pass #return scarceLootList[random.randint(0, 100)]
        elif(random.randint(0, 100) < enemy.yieldRare()):
            pass #return rareLootList[random.randint(0, 100)]



        
    
